# TGddosbot
## Телеграмм бот для DDos -a сайтов

**Установка кода:**
```
git clone https://github.com/0xSn1kky/TGddosbot.git
```

**Установка модулей:**
```
python download.py
```

**Запуск:**
```
python main.py
```
